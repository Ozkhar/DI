﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIPlayer
{
    /// <summary>
    /// The class player and the methods from the "PlayerDataAccess" are decoupled.
    /// </summary>
    public class Player
    {
        public string Name { get; private set; }
        public int ExperiencePoints { get; private set; }
        public int Gold { get; private set; }

        public Player(string name, int experiencePoints, int gold)
        {
            Name = name;
            ExperiencePoints = experiencePoints;
            Gold = gold;
        }

        /// <summary>
        /// Injection happens here in the constructor. An object of type IPlayerDat is passed.
        /// </summary>
        /// <param name="name">Player Name</param>
        /// <param name="playerData">Interface</param>
        /// <returns></returns>
        public static Player CreateNewPlayer(String name, IPlayerData playerData = null)
        {
            if (playerData == null)
            {
                playerData = new PlayerDataAccess();
            }
            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentException("Player cannot be empty");
            }
            
            PlayerDataAccess _playerDataAccess = new PlayerDataAccess();

            //Checks if there is already a Player with that specific name in the Database.
            //The method "PlayerExistInDataBase" is decoupled and here is called from the interface.
            if (_playerDataAccess.PlayerExistInDataBase(name))
            {
                throw new ArgumentException("Player name already exist");
            }

            //Inserts Player in the Data Base
            //The method "InsertNewPlayerIntoDatabase" is decoupled and here is called from the interface.
            _playerDataAccess.InsertNewPlayerIntoDatabase(name);

            return new Player(name, 0, 10);
        }

        static void Main(string[] args)
        {
            //CreateNewPlayer("Fly");
            //CreateNewPlayer("Cloud");
            //CreateNewPlayer("Goku");

            CreateNewPlayer("Rikus");
            CreateNewPlayer("Cloud");
            CreateNewPlayer("Mana");


        }
    }
}

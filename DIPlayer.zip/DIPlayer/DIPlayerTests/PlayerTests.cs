﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using DIPlayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIPlayer.Tests
{
    [TestClass()]
    public class PlayerTests
    {
        [TestMethod()]
        [ExpectedException(typeof(ArgumentException))]
        public void Test_CreateNewPlayer_EmptyName_MockedData()
        {
            MockPlayer mockPlayer = new MockPlayer();

            Player player = Player.CreateNewPlayer("", mockPlayer);
        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentException))]
        public void Test_CreateNewPlayer_AlreadyExis_MockedData()
        {
            MockPlayer mockPlayer = new MockPlayer();

            mockPlayer.ResultToReturn = true;

            Player player = Player.CreateNewPlayer("Test", mockPlayer);
        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentException))]
        public void Test_CreateNewPlayer()
        {    
             //Player player = Player.CreateNewPlayer("Goku", null);
        }
    }
}
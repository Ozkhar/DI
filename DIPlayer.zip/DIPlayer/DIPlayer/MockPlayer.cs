﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIPlayer
{
    /// <summary>
    /// This class is for testing purposes... we pretend that we are hitting the data base.
    /// </summary>
    public class MockPlayer : IPlayerData
    {
        public bool ResultToReturn{ get; set; }

        public bool PlayerExistInDataBase(String name)
        {
            return ResultToReturn;
        }

        public void InsertNewPlayerIntoDatabase(String name)
        {

        }
    }
}

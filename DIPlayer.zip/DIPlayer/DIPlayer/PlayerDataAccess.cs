﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DIPlayer
{
    /// <summary>
    /// Class which access to the Database.
    /// </summary>
    public class PlayerDataAccess : IPlayerData
    {
        private readonly string _connectionString = "Server=TOKYO\\SQLEXPRESS; database=TestDB; Trusted_Connection=True";

        /// <summary>
        /// Method that checks if the Player exist in the database.
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public bool PlayerExistInDataBase(string name)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                using (SqlCommand playersWithThisName = connection.CreateCommand())
                {
                    playersWithThisName.CommandType = CommandType.Text;
                    playersWithThisName.CommandText = "SELECT COUNT(*) FROM PLAYER WHERE PLAYERNAME = @NAME";

                    playersWithThisName.Parameters.AddWithValue("@Name", name);

                    //Get number of players with this name.
                    var existingRowCount = (int)playersWithThisName.ExecuteScalar();

                    //Result is 0, if no player exists, or 1 is a player already exists
                    return existingRowCount > 0;                     
                }
            }
        }

        /// <summary>
        /// Method that inserts into the Database.
        /// </summary>
        /// <param name="name"></param>
        public void InsertNewPlayerIntoDatabase(string name)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                using (SqlCommand playersWithThisName = connection.CreateCommand())
                {
                    playersWithThisName.CommandType = CommandType.Text;
                    playersWithThisName.CommandText = "INSERT INTO PLAYER(PlayerName) VALUES(@NAME)";

                    playersWithThisName.Parameters.AddWithValue("@Name", name);

                    //Get number of players with this name.
                    playersWithThisName.ExecuteScalar();                    
                }
            }


            
        }
    }
}
